import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  base: './',
  plugins: [react()],
  build: {
    outDir: 'dist',
    emptyOutDir: true,
    rollupOptions: { input: 'src/ui/index.html', output: { entryFileNames: 'ui.js', assetFileNames: '[name][extname]' } },
  },
  server: { host: '127.0.0.1', port: 5173, strictPort: true },
});
