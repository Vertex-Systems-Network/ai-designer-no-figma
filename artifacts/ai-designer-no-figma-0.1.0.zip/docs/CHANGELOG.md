# Changelog






## Unreleased: design fidelity (Penpot → Figma report)

Fixes 12 issues found while importing a Penpot design into Figma through the Figma Local connector:

1. `figma_get_schema` returns the JSON Schema, a property reference and an example; new `docs/DESIGN-SCHEMA.md`.
2. Validation errors name the real field (`…gradient.stops[0].color: missing required property`). Paint and effect mistakes no longer report "Unsupported layer type".
3. Linear gradients accept `angle`, `start`/`end`, `handles`, `offset` stops and percentages; `direction` defaults to horizontal.
4. Fonts: weights map to the installed style (800 → ExtraBold / Extra Bold); new `fontStyle`; fallbacks are reported as job warnings.
5. `textAutoResize` is applied after sizing, so `WIDTH_AND_HEIGHT` no longer wraps.
6. Text alignment accepts `textAlign`, `textAlignHorizontal` and lowercase values.
7. Image `scaleMode` defaults to `FILL`.
8. Groups become real Figma groups; children are relative to the group's x/y, and Figma sizes the group from its children.
9. Per-corner radius accepts `radius:[tl,tr,br,bl]`, `radius:{topLeft,…}` and `topLeftRadius`-style fields.
10. Images by `src` (file path or URL) or `assetRef` from `figma_upload_image`, up to 5 MB, sent in chunks. Large base64 is uploaded automatically, and images no longer drop out of imports.
11. `targetPageId`, `replacePage`, `figma_list_pages` and `figma_delete_page`.
12. Import results report `pages`, `nodes` and `warnings`.

Also: `#RRGGBBAA` and `rgba()` colours, `fills` as an alias of `paints`, letter-spacing numbers, and line-height objects.

## Unreleased: plugin → agent requests, tunnel hardening, illustrated guide

- With an agent paired, Generate and Edit selection send the brief straight to it (bridge request queue + MCP tool `figma_get_design_requests`; the server instructions tell agents to check it). Without an agent, the copy-paste prompt flow is unchanged.
- Tunnel supervisor: deadline on every provider start, flapping tunnels count as failures, return to the preferred provider after a healthy run ends, prompt Ctrl+C during back-off, servers closed if browser-mode setup fails, and the correct startup hint for `--tunnel=<provider>`.
- USER-GUIDE: architecture, local-mode, browser-mode and request-flow diagrams (`docs/images/*.svg`).

## Unreleased: permanent browser-mode tunnel

- `npm run mcp:browser` now supervises its own tunnel: a permanent address (a saved localtunnel subdomain or an ngrok static domain), automatic reconnects with back-off, and `auto` provider fallback (ngrok, then localtunnel, then Cloudflare). It warns when the address changes. Settings: `~/.ai-designer-no-figma/browser-mode.json`; per-run override `--tunnel=<provider>`.
- New dependency: `localtunnel` (run `npm install` after pulling).

## Unreleased: agent loader and naming

- While an MCP job runs with the panel hidden, the plugin pops up a small branded loader (AI Designer logo and spinner, "<agent> is working"), then hides again. With the panel open, a status bar shows the same.
- Jobs are labeled with the real agent name from the MCP handshake (Claude, ChatGPT, Cursor, …) instead of "MCP client".
- `figma_export_selection` falls back to the page's only top-level frame when nothing is selected, and otherwise names the frames to pick from.
- Docs: tunnel fallbacks (localtunnel, ngrok) and rotating the secret.

## Unreleased: browser mode, agent presence, setup hardening

- Browser mode: `npm run mcp:browser` starts the hub plus a Cloudflare quick tunnel and prints a ChatGPT / Claude.ai connector URL. The hub accepts the secret in the path (`/mcp/<secret>`) as well as the Bearer header; non-POST methods return 405.
- Local and browser mode together: `setup:clients --client claude-desktop --mode http` points Claude Desktop at the shared hub through `mcp-remote`.
- Agent presence: while an MCP job runs, Figma shows a persistent toast with the agent's name (Figma's avatar row cannot list plugins).
- `setup:clients`: refuses to write Claude Desktop's config while the app runs, and verifies the entry after writing.
- Docs: new `docs/USER-GUIDE.md`, linked from the README.

## Unreleased
- Fixed (found live): the pairing token, settings and asset-library access were lost on every plugin restart, because the iframe's `localStorage` is not persistent. They are now stored in `figma.clientStorage`.
- KI-003 live verified: in a rebuilt plugin, Undo of a set-bounds + rename + set-fill patch now restores the name, width and token-bound fill without errors.
- Fixed (found live): Undo of a bounds/rename/fill patch could fail half-way with an unloaded-font error, leaving the name and width changed. Patch apply and undo now load every text target's fonts first and rewrite text only when it changed.
- Imported pages get a unique name (`Name (2)`) instead of duplicating an existing page name; seen live when an exported selection was re-imported.
- LIVE-01 core flow verified in Figma Desktop 126.11.8 (Windows): native kit render; selection-aware set-text patch with a preview of the untouched layers; change propagated to an instance; Undo; selected export to schema 1.0 with tokens; re-import as editable nodes.
- Live Figma (LIVE-01/02 partial): the component kit rendered native components, instances and variable-bound fills; pairing with the Claude Desktop extension worked. The kit now declares FIXED Auto Layout sizing and fixed-width text explicitly. This is a clarification, not a bug fix: an early note about a narrow input field was disproved by measuring the live layer, which was 320 px wide (Input/Text 320 × 65, Field 320 × 44, built before PR #24).
- Issue #2: `buildComponentKit` and the MCP tool `figma_build_component_kit` create token-bound native components (buttons, input, card, navigation, table row, usage instances) with WCAG AA colors. The Design System tab can now build the kit in Figma and import or export presets.
- Issue #5: added a versioned migration layer (`spec-migrations.ts`) that upgrades loose or unversioned model output to schema 1.0 and reports each change. MCP import and the design agent use it.
- Issue #7: `npm run bench` performance fixtures; results are in `docs/PERFORMANCE.md`.
- Issue #3: the patch preview now lists the selected layers that stay unchanged.
- Qodo review fixes: runtime bearer auth through a terminal pairing code, bridge instance identity, per-port pairing codes, trusted lockout reset, a hub URL file, owner-only token configs, and the stdio entry guard.
- Security: plugin pairing now requires a 6-digit user code (MCP tool `figma_get_pairing_code`, file `~/.ai-designer-no-figma/pairing-code`); 5 wrong codes lock pairing for 60 s and rotate the code. Previously any web page sending `Origin: null` could obtain the plugin bridge token.
- Fixed: the hub (`mcp:remote` / `mcp:hub`) also started the stdio server's bridge, creating two bridges with different codes.
- Fixed: the local runtime rejected the Figma plugin iframe's `null` origin, so model generation could not work inside Figma. Generation is now limited to one job at a time.
- Added a multi-provider runtime: Ollama, LM Studio, OpenAI, Anthropic, Gemini, OpenRouter, Groq, DeepSeek, Mistral, xAI and custom OpenAI-compatible, Anthropic or Gemini endpoints through `providers.json`. Keys stay in the local process.
- Added `npm run setup:clients` for Claude Desktop, Claude Code, Cursor, VS Code Copilot, Windsurf, Cline, Gemini CLI, Codex, LM Studio, Zed and a `custom` option. See `docs/AI-CLIENTS.md`.
- Running jobs can now be stopped: `figma_cancel_job` flags the job and the plugin heartbeat relays the stop to an active render.
- `figma_get_capabilities` now reports the real paint, effect and patch support. The stdio server picks a free bridge port, so more than one AI app can run.
- Verification: 138 unit + 29 integration tests, lint, typecheck, build, strict docs audit (0 findings), packages rebuilt. Live Figma, real models and real AI apps remain NOT TESTED.
- Completed schema 1.0 import/export fidelity review. Text export now uses a single canonical color property; explicit typography overrides are applied after referenced text styles; unsupported text/line corner radius and conflicting text color aliases are rejected. Added the field-group fidelity matrix and regression coverage. Release verification: 107 unit + 17 integration tests, build/package, strict docs audit, ZIP integrity and SHA-256 pass. Live Figma round-trip remains NOT TESTED.
- Fixed selected-tree export dropping bound color variable and text-style definitions because async traversal was snapshotted too early; added host behavior regression coverage. Release verification passed with 101 unit and 17 integration tests, strict docs audit (0 findings), ZIP integrity and SHA-256.
- Expanded selected-export behavior coverage for geometry, rotation, clipping, Auto Layout, typography and constraints alongside tokens.
- Added actual plugin-host export fixtures for editable vectors, detached component/instance references, embedded raster crop metadata, gradients, shadows, and explicit rejection of unsupported effects/node types/multiple strokes. Mixed font/line-height styles and multiple text color tokens now fail safely instead of being silently dropped.
- Corrected native font-weight mapping across light, regular, medium, semibold, bold, extrabold and black styles. Preserve rounded corners/strokes when exporting image-filled rectangles; fail explicitly for visible strokes on layer types whose schema has no stroke fields.
- Export rejects compound vector paths and modified/scaled instances when the current spec cannot retain their contents or appearance. Host fixture now round-trips all grid variants and extended text/token properties.
- Added behavior-level Figma host tests for selected patch/undo, sibling preservation, rollback after a partially mutating failure, and cleanup of pages created before a later render failure.
- Published the exact-source ZIP and SHA-256 manifest with the plan/prompt corrections on GitHub `main`; verified its Git blob against the local archive bytes.
- Replaced conflicting roadmap percentages and stale acceptance checklists with one evidence-driven execution plan and engineering master prompt; agent rules now resume the first unblocked task and explicitly separate live Figma/client gates from plugin-only capabilities.
- Targeted edits can rotate selected layers within -180° to 180°; rotation is included in plugin rollback/undo checkpoints.
- Native node rotation now validates in the -180° to 180° range, is applied on render, and survives selected-tree export.
- Frame, component and rectangle specifications now support distinct corner radii and Figma corner smoothing; selected export round-trips them and renderer applies them natively.
- Line export now preserves single-stroke opacity and rejects multiple visible strokes or unsupported blend/stroke types instead of silently discarding them; imported lines restore stroke opacity.
- Added schema-backed `clipsContent` for frames and components; native rendering applies it and selected-tree export preserves enabled clipping. Groups safely reject the unsupported field.
- Selected export now rejects non-normal node, paint, and shadow blend modes that schema 1.0 cannot represent, instead of silently dropping them; Normal and default pass-through containers remain exportable.
- Release verification after blend-mode, clipping, stroke, corner-fidelity, and rotation support: 101 unit tests and 17 integration tests pass; typecheck, lint, local audit, build/package, strict docs audit (0 findings), ZIP integrity, and SHA-256 pass. Live Figma export remains NOT TESTED.
- Exposed image Fill/Fit/Tile/custom crop patching in Edit with a bounded TILE scale-factor control. Automated release verification passes; live image appearance remains NOT TESTED.
- Preserved native image crop/reposition transforms in the versioned design spec for standalone image nodes and image paint stacks; the renderer restores them and selected export emits them. Schema checks require CROP mode and an invertible bounded affine transform.
- Added schema-backed TILE image fills with a bounded `scalingFactor` for standalone image nodes and layered paints; native image repetition now renders and round-trips through selected export.
- Edit now proposes and previews a TILE scale-factor patch alongside FILL/FIT/CROP changes. The operation preserves image data and other paint settings and participates in existing rollback.
- Added reviewed FILL/FIT/CROP mode and affine image reposition patches for one selected image fill. Crop matrices are finite, invertible 2×3 transforms bounded to ±10; paint opacity, blend and source bytes are preserved, and patch undo restores the original paint. The Edit UI exposes a mode selector and transform editor when an image fill is selected.
- Added reviewed replacement of exactly one existing selected image fill from a validated PNG/JPEG (128 KiB cap), preserving its scale/opacity and enabling patch undo. Live Figma crop appearance and rollback remain NOT TESTED.

- Text nodes and reusable typography tokens now support paragraph spacing; text nodes additionally import/export vertical alignment and fixed/height/auto resize behavior.

- Added schema-backed text letter spacing (pixels/percent), case transforms, and underline/strikethrough with native import and selected-layer export; mixed per-character formatting fails explicitly instead of being flattened.

- Added schema-validated solid outlines for rectangle and ellipse nodes, including opacity, width and alignment. Import renders native strokes; selected-layer export preserves single normal solid strokes and clearly rejects unsupported multi-stroke or blended outlines.
- Added native angular and diamond gradient paints with bounded affine transforms, schema checks, rendering, and selected-tree export round-trip.
- Added native radial-gradient paint stacks with bounded affine transforms, editable Figma paint rendering, validation against singular matrices, and selected-tree export round-trip.
- Added bounded affine 2×3 transforms for linear gradients. Diagonal and rotated linear gradients now preserve their Figma transform through import/export; radial, angular and diamond gradients are supported with bounded transforms.
- Added bounded native effect stacks for inner/drop shadows and normal and progressive layer/background blur. Import/export retains order and supported settings; other unsupported effects are rejected explicitly.
- Added schema-validated embedded PNG/JPEG image paints in ordered fill stacks, including opacity and FIT/FILL/CROP scale modes. Figma export re-embeds bounded raster bytes; unsupported effects and transformed gradients remain explicitly rejected.

## Unreleased
- Added validated schema support and native renderer/export round-trip for up to eight stacked solid, linear-gradient, and embedded PNG/JPEG fills, including independent paint opacity.
- Added bounded stacks of up to four native drop shadows with order/opacity preserved in render and selected-tree export; non-drop-shadow effects remain explicit errors.
- Added a reviewed `swap-component` patch for selected instances and components, with rollback snapshots for the previous main component and component property values.
- Release verification: 62 unit and 17 integration tests passed; typecheck, lint, local audit, build/package, strict docs audit (0 findings), ZIP integrity and SHA-256 passed. Live Figma visual round-trip remains NOT TESTED.

## 2026-11-09 — advanced native renderer and design schema

- Extended design-spec 1.0 with reusable components and instances, bounded SVG path vectors, horizontal/vertical linear gradients, and drop shadows.
- Added native Figma `ComponentNode`, instance, vector-path, gradient-paint, and drop-shadow rendering, plus prompt guidance and honest MCP capability reporting.
- Added positive and negative schema/renderer capability regression cases. Typecheck and focused tests pass; a live Figma render is NOT TESTED because the user is unavailable for that verification.
- Raster image nodes, Figma Variables/styles, and complete selected-tree export round-tripping remain open.

## 2026-11-09 — AI-orchestrated visual feedback loop

- Added Figma frame capture through `exportAsync` as a JPEG preview. The host tries 1024/768/512 px widths and enforces a 700 KiB byte cap, one selected frame, supported aspect ratio and 8192 px maximum preview height.
- Newly rendered pages select and zoom to their first root frame so an AI client can capture immediately.
- Added MCP `figma_capture_selection`; completed capture results are returned by `figma_get_job_result` as an actual image content block. Tool descriptions guide the agent to inspect, make targeted edits and capture again.
- Added byte encoding and preview validation tests. This supports an AI client driven review cycle; it does not make the plugin call Claude or prove live Figma image delivery.

## 2026-11-08 — design quality review slice

- Strengthened provider-neutral generation prompts with concrete hierarchy, grid, semantic naming, readable contrast, realistic content and layer-quality requirements.
- Added a non-blocking design-spec audit for low contrast when solid fills are known, generic layer names, missing explicit font sizes, and multi-child containers without Auto Layout. Findings are shown in Import with exact JSON paths; imports remain valid and insertable.
- Added deterministic positive/negative fixture coverage. This is not screenshot analysis or proof of visual superiority over Figma Agent.

## Unreleased — repository intelligence and MCP foundation

- Moved authenticated MCP bridge polling and network requests out of the Figma JSVM host into the browser-based plugin UI iframe. The host now handles only Figma document work and returns correlated job results to the UI. Added a Connect & hide flow using `figma.ui.hide()`, background heartbeat while jobs run, a Figma toast for each job's working/completed/failed state, and display of the signed-in Figma operator via the declared `currentuser` permission. Added a regression suite preventing browser network/timer globals from returning to the Figma host. Closing Figma or the current document still ends the session; new-file automation needs a separate desktop runner.
- Replaced Figma/browser storage for imported assets with validated, size-bounded persistence in the private local bridge file, because the user's Figma context denies IndexedDB and plugin storage. Pair credentials now persist across bridge restarts, and plugin bridge endpoint validation no longer uses the unavailable Figma JSVM `URL` global. Typecheck, lint, build, MCPB packaging and ZIP packaging pass; live Windows Claude/Figma confirmation is pending.
- Removed the plugin host's `AbortController` dependency from bridge requests; the Figma JSVM now uses a bounded timeout race and reports a useful reconnection message on slow requests.
- Added canonical cross-agent repository instructions and source-aware project status documents.
- Added the official `@modelcontextprotocol/server` SDK dependency (2.4.0); no MCP server is claimed until its stdio implementation and tests exist.
- Added selected Figma layer export, bounded selection geometry edits and plugin-session undo in the current code line; see README and backlog for verification state.
- Added bounded native SVG and PNG/JPEG/GIF asset imports, validation MCP tools, the AI Assets UI, local recent-import metadata, and explicit client capability reporting. Automated validation exists; native asset rendering has not been live-verified.
- Implemented SHA-256 integrity checks, persistent image/vector bytes, preview, reuse, deletion and clear actions. Added post-insert Figma node readback checks for dimensions, vector children and native image fills. Added atomic MCP batch queueing and 64 KiB SHA-256-verified raster chunks for transfers up to 5 MiB.
- Added reviewed frame-only Auto Layout patch operations with validation, application, rollback snapshots and undo support.
- Added locally persisted typography and spacing scales with bounded import/export validation; both scales are attached to local-model and external-AI design prompts.
- Added up to 20 named design-system presets with save/load/duplicate/delete controls.

## 0.1.0

- Initial local-first Figma plugin, editable basic node renderer, JSON import/validation, external AI handoff, optional local Ollama service, history/tokens and ZIP packaging.
# 0.2.0 work in progress — 2026-11-08

- Added custom stdio MCP tools for connection state, sessions, capabilities, selection inspection, schema import, selected-layer patches/export and job lifecycle.
- Added a token-authenticated loopback bridge with session-correlated queue, payload bounds, origin allowlist and result handling.
- Added plugin pairing settings and an Agent Activity timeline driven by actual bridge events.
- Added bundled MCP server build, docs/source registration auditing, compatibility metadata reporting and release verification.
- The 2026-11-08 release verification before the Figma storage compatibility fix passed 31 unit tests and 15 integration tests, typecheck, lint, local security audit, build, packaging, strict docs audit (0 findings), ZIP integrity and SHA-256. The earlier localStorage fallback passed 33 unit tests and 15 integration tests, then was replaced after the user confirmed Figma blocks UI iframe storage. The new Figma clientStorage host bridge and structural readback checks passed 36 unit tests and 15 integration tests, typecheck/lint, local security audit, build/package, strict docs audit (0 findings), ZIP integrity and SHA-256. Live Figma save/reuse confirmation is still pending.

## 2026-11-09 — image, token, responsive layout, and export coverage

- Added schema-backed bounded PNG/JPEG design nodes and deterministic base64/MIME validation.
- Added native color Variable and Text Style creation/binding, responsive constraints, and row/column/grid layout definitions in the Figma renderer.
- Extended supported selected-tree export for images, token references, grids, constraints, component definitions, gradients, vectors and shadows; unsupported data now fails explicitly.
- Added category-specific generation recipes for website, dashboard, mobile app, admin, WordPress admin, e-commerce, landing page and custom interfaces.
- Automated release verification passed with 55 unit and 17 integration tests, typecheck/lint, local audit, build/package, strict docs audit (0 findings), ZIP integrity and SHA-256. Live Figma rendering and export/import round-trip remain NOT TESTED.


## 2026-11-09 — compatibility mappings and local model streaming

- Added a typings-backed compatibility module for schema Auto Layout modes and primary-axis alignment, with deterministic mapping round-trip tests.
- Local Ollama generation now receives the complete provider-neutral schema/category instructions, streams bounded NDJSON to the UI, reports actual output received, and propagates cancellation upstream. Patch prompts now include the supported Auto Layout operation.
- Release verification passed: 55 unit and 17 integration tests, typecheck/lint, local audit, build/package and strict docs audit (0 findings). No local Ollama service or live Figma editor was available for verification.

- 2026-11-12: Added optional bounded Figma reference notes to the external AI handoff and documented official MCP interoperability boundaries.

- 2026-11-12: Added local MCP design-schema audit with overflow/text collision diagnostics and documented staged agent design workflow.

- 2026-11-12: Added `figma_get_local_design_system` with bounded read-only inventory of current-page components and local variables/styles.

- 2026-11-12: Added versioned design plan validator and `figma_validate_design_plan` MCP tool.

- 2026-11-12: Added native component family 1.0 create/export MCP tools with bounded variants, text property, instances and rollback.
