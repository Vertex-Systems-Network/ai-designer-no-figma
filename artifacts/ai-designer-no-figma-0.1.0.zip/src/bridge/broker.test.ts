import { describe, expect, it } from 'vitest';
import { BridgeFault, JobBroker } from './broker';

describe('local Figma job broker',()=>{
  it('requires an active target session and supports idempotent enqueue',()=>{
    const broker=new JobBroker();
    expect(()=>broker.enqueue({type:'inspect-selection'})).toThrowError(BridgeFault);
    broker.connect('figma-session-1','0.2.0');
    const first=broker.enqueue({type:'inspect-selection'},{operationId:'stable-op-1'});
    const duplicate=broker.enqueue({type:'inspect-selection'},{operationId:'stable-op-1'});
    expect(duplicate.jobId).toBe(first.jobId);
    expect(broker.takeNext('figma-session-1')).toMatchObject({jobId:first.jobId,status:'running'});
  });

  it('correlates results to their assigned session and retains truthful results',()=>{
    const broker=new JobBroker();broker.connect('figma-session-1','0.2.0');broker.connect('figma-session-2','0.2.0');
    const job=broker.enqueue({type:'inspect-selection'},{sessionId:'figma-session-1'});
    expect(broker.takeNext('figma-session-2')).toBeNull();
    broker.takeNext('figma-session-1');
    expect(()=>broker.complete('figma-session-2',job.jobId,true,{nodes:0})).toThrowError(/different plugin session/);
    expect(broker.complete('figma-session-1',job.jobId,true,{nodes:4})).toMatchObject({status:'completed',result:{nodes:4}});
    expect(broker.getJob(job.jobId).result).toEqual({nodes:4});
  });

  it('cancels queued work and flags running work for a cooperative stop',()=>{
    const broker=new JobBroker();broker.connect('figma-session-1','0.2.0');
    const queued=broker.enqueue({type:'inspect-selection'});
    expect(broker.cancel(queued.jobId).status).toBe('cancelled');
    const active=broker.enqueue({type:'inspect-selection'});broker.takeNext('figma-session-1');
    expect(broker.cancel(active.jobId)).toMatchObject({status:'running',cancelRequested:true});
    expect(broker.cancellationsFor('figma-session-1')).toEqual([active.jobId]);
    broker.complete('figma-session-1',active.jobId,true,{});
    expect(()=>broker.cancel(active.jobId)).toThrowError(/already completed/);
  });

  it('expires disconnected sessions and bounds active work',()=>{
    let now=10_000;const broker=new JobBroker({now:()=>now,sessionTtlMs:100,maxJobs:1});
    broker.connect('figma-session-1','0.2.0');broker.enqueue({type:'inspect-selection'});
    expect(()=>broker.enqueue({type:'inspect-selection'})).toThrowError(/queue is limited/);
    now+=101;
    expect(broker.getSessions()).toEqual([]);
    expect(()=>broker.enqueue({type:'inspect-selection'})).toThrowError(/No paired Figma/);
  });

  it('reserves a chunk transfer batch atomically and preserves its order',()=>{
    const broker=new JobBroker({maxJobs:3});broker.connect('figma-session-1','0.2.0');
    const operations=[{type:'begin-image-transfer' as const,transferId:'01234567-89ab-cdef-0123-456789abcdef',name:'large.png',mimeType:'image/png' as const,totalBytes:9,sha256:'a'.repeat(64),chunkCount:1},{type:'image-transfer-chunk' as const,transferId:'01234567-89ab-cdef-0123-456789abcdef',index:0,bytes:[1,2,3]},{type:'finish-image-transfer' as const,transferId:'01234567-89ab-cdef-0123-456789abcdef'}];
    const jobs=broker.enqueueBatch(operations,{operationId:'large-image'});expect(jobs).toHaveLength(3);
    expect(jobs.map(job=>job.operation.type)).toEqual(['begin-image-transfer','image-transfer-chunk','finish-image-transfer']);
    expect(broker.takeNext('figma-session-1')?.jobId).toBe(jobs[0]?.jobId);
    expect(()=>broker.enqueueBatch(operations,{operationId:'another-transfer'})).toThrowError(/batch needs 3/);
    expect(broker.getSessions()).toHaveLength(1);
  });
});
