import type { EditPatch } from './protocol';
import { utf8ByteLength } from './utf8';
import { decodeBase64 } from './base64';
import { validateRasterAsset } from './assets';

export const MAX_PATCH_IMAGE_BYTES = 128 * 1024;

export type PatchValidation = { valid: true; value: EditPatch } | { valid: false; message: string };

export function parseEditPatch(json: string, allowedIds?: ReadonlySet<string>): PatchValidation {
  if (utf8ByteLength(json) > 262_144) return { valid: false, message: 'Patch JSON exceeds the 256 KB limit.' };
  const source = json.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
  let parsed: unknown;
  try { parsed = JSON.parse(source); }
  catch { return { valid: false, message: 'Invalid patch JSON. Check commas, quotes, and braces.' }; }
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed) || Object.keys(parsed).some((key) => key !== 'operations')) {
    return { valid: false, message: 'Patch must be an object containing only an operations array.' };
  }
  const operations = (parsed as { operations?: unknown }).operations;
  if (!Array.isArray(operations) || operations.length > 100) return { valid: false, message: 'Patch must contain an operations array with at most 100 entries.' };
  for (const [index, item] of operations.entries()) {
    const path = `operations[${index}]`;
    if (!item || typeof item !== 'object' || Array.isArray(item)) return { valid: false, message: `${path} must be an object.` };
    const op = item as Record<string, unknown>;
    const allowedKeys = ['op', 'targetId', 'value'];
    if (Object.keys(op).some((key) => !allowedKeys.includes(key)) || Object.keys(op).length !== 3) return { valid: false, message: `${path} must contain only op, targetId, and value.` };
    if (!['set-text', 'set-fill', 'rename', 'set-bounds', 'set-rotation', 'set-auto-layout','swap-component','replace-image','set-image-crop'].includes(String(op.op))) return { valid: false, message: `${path}.op is unsupported.` };
    if (typeof op.targetId !== 'string' || !op.targetId || op.targetId.length > 200) return { valid: false, message: `${path}.targetId must be a non-empty string.` };
    if (allowedIds && !allowedIds.has(op.targetId)) return { valid: false, message: `${path}.targetId is not present in the current selection.` };
    if (op.op === 'set-bounds') {
      if (!op.value || typeof op.value !== 'object' || Array.isArray(op.value)) return { valid: false, message: `${path}.value must contain x, y, width, and height numbers.` };
      const bounds = op.value as Record<string, unknown>;
      if (Object.keys(bounds).length !== 4 || !['x','y','width','height'].every((key) => key in bounds)) return { valid: false, message: `${path}.value must contain only x, y, width, and height.` };
      if (typeof bounds.x !== 'number' || !Number.isFinite(bounds.x) || Math.abs(bounds.x) > 100_000 || typeof bounds.y !== 'number' || !Number.isFinite(bounds.y) || Math.abs(bounds.y) > 100_000 || typeof bounds.width !== 'number' || !Number.isFinite(bounds.width) || bounds.width <= 0 || bounds.width > 100_000 || typeof bounds.height !== 'number' || !Number.isFinite(bounds.height) || bounds.height <= 0 || bounds.height > 100_000) return { valid: false, message: `${path}.value has invalid bounds; x/y must be within ±100,000 and width/height must be 1–100,000.` };
      continue;
    }
    if (op.op === 'set-rotation') {
      if (typeof op.value !== 'number' || !Number.isFinite(op.value) || op.value < -180 || op.value > 180) return { valid: false, message: `${path}.value must be a rotation between -180 and 180 degrees.` };
      continue;
    }
    if(op.op==='set-auto-layout'){
      if(!op.value||typeof op.value!=='object'||Array.isArray(op.value))return{valid:false,message:`${path}.value must contain mode, gap, padding, and alignment.`};
      const layout=op.value as Record<string,unknown>;const keys=['mode','gap','padding','alignment'];
      if(Object.keys(layout).length!==keys.length||keys.some(key=>!(key in layout)))return{valid:false,message:`${path}.value must contain only mode, gap, padding, and alignment.`};
      if(!['NONE','HORIZONTAL','VERTICAL'].includes(String(layout.mode)))return{valid:false,message:`${path}.value.mode must be NONE, HORIZONTAL, or VERTICAL.`};
      if(typeof layout.gap!=='number'||!Number.isFinite(layout.gap)||layout.gap<0||layout.gap>1000||typeof layout.padding!=='number'||!Number.isFinite(layout.padding)||layout.padding<0||layout.padding>1000)return{valid:false,message:`${path}.value gap and padding must be between 0 and 1,000.`};
      if(!['MIN','CENTER','MAX','SPACE_BETWEEN'].includes(String(layout.alignment)))return{valid:false,message:`${path}.value.alignment is unsupported.`};
      continue;
    }
    if(op.op==='replace-image'){
      if(!op.value||typeof op.value!=='object'||Array.isArray(op.value))return{valid:false,message:`${path}.value must contain mimeType and base64 data.`};
      const image=op.value as Record<string,unknown>;
      if(Object.keys(image).length!==2||!['mimeType','data'].every(key=>key in image)||!['image/png','image/jpeg'].includes(String(image.mimeType))||typeof image.data!=='string')return{valid:false,message:`${path}.value must contain only a PNG/JPEG mimeType and base64 data.`};
      try{const bytes=decodeBase64(image.data,MAX_PATCH_IMAGE_BYTES);validateRasterAsset(bytes,String(image.mimeType));}catch(error){return{valid:false,message:`${path}.value image is invalid: ${error instanceof Error?error.message:'invalid raster data'}`};}
      continue;
    }
    if(op.op==='set-image-crop'){
      if(!op.value||typeof op.value!=='object'||Array.isArray(op.value))return{valid:false,message:`${path}.value must contain a scaleMode and, for CROP, an imageTransform.`};
      const crop=op.value as Record<string,unknown>;
      if(!['FILL','FIT','CROP','TILE'].includes(String(crop.scaleMode)))return{valid:false,message:`${path}.value.scaleMode must be FILL, FIT, CROP, or TILE.`};
      if(crop.scaleMode==='CROP'){
        if(Object.keys(crop).length!==2||!Array.isArray(crop.imageTransform)||crop.imageTransform.length!==2||!crop.imageTransform.every(row=>Array.isArray(row)&&row.length===3&&row.every(value=>typeof value==='number'&&Number.isFinite(value)&&Math.abs(value)<=10)))return{valid:false,message:`${path}.value.imageTransform must be a finite 2×3 matrix with values within ±10.`};
        const matrix=crop.imageTransform as [[number,number,number],[number,number,number]];const determinant=matrix[0][0]*matrix[1][1]-matrix[0][1]*matrix[1][0];
        if(Math.abs(determinant)<0.0001||Math.abs(determinant)>100)return{valid:false,message:`${path}.value.imageTransform must be invertible with a bounded scale.`};
      }else if(crop.scaleMode==='TILE'){
        if(Object.keys(crop).some(key=>!['scaleMode','scalingFactor'].includes(key))||(crop.scalingFactor!==undefined&&(typeof crop.scalingFactor!=='number'||!Number.isFinite(crop.scalingFactor)||crop.scalingFactor<=0||crop.scalingFactor>10)))return{valid:false,message:`${path}.value for TILE must contain only a scalingFactor greater than 0 and at most 10.`};
      }else if(Object.keys(crop).length!==1)return{valid:false,message:`${path}.value may contain only scaleMode for FILL or FIT.`};
      continue;
    }
    if(op.op==='swap-component'){
      if(typeof op.value!=='string'||!op.value||op.value.length>200)return{valid:false,message:`${path}.value must be an existing component ID.`};
      if(allowedIds&&!allowedIds.has(op.value))return{valid:false,message:`${path}.value is not present in the current selection.`};
      continue;
    }
    if (typeof op.value !== 'string' || op.value.length > 20_000) return { valid: false, message: `${path}.value must be a string no longer than 20,000 characters.` };
    if (op.op === 'set-fill' && !/^#[0-9a-f]{6}$/i.test(op.value)) return { valid: false, message: `${path}.value must be a six-digit hex color for set-fill.` };
  }
  return { valid: true, value: parsed as EditPatch };
}
